import { html } from '../../node_modules/lit-html/lit-html.js';

//TODO replace with actual view
const homeTemplate = () => html `
`;


export function homePage(ctx) {
    ctx.render(homeTemplate());
}