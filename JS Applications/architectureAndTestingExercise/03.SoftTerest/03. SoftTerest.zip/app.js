import { logout } from './users.js';
import { initialize } from './router.js';
import { showCatalog } from './catalog.js';
import { showCreate } from './create.js';
import { showDetails } from './details.js';
import { showHome } from './home.js';
import { showLogin } from './login.js';
import { showRegister } from './register.js';

document.querySelector('#views').remove();

const links = {
    '/': showHome,
    '/catalog': showCatalog,
    '/login': showLogin,
    '/register': showRegister,
    '/details': showDetails,
    '/create': showCreate,
    '/logout': onLogout,
};

const router = initialize(links);
router.updateNav();
router.goto('/');

function onLogout() {
    logout();
    router.updateNav();
    router.goto('/');
}